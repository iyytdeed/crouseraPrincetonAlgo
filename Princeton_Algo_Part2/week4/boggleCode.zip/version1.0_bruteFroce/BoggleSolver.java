import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

import edu.princeton.cs.algs4.SET;

public class BoggleSolver
{
    private SET<String> dictSet;
    
    // Initializes the data structure using the given array of strings as the dictionary.
    // (You can assume each word in the dictionary contains only the uppercase letters A through Z.)
    public BoggleSolver(String[] dictionary){
        dictSet = new SET<String>();
        for(int i = 0; i < dictionary.length; i++){
            this.dictSet.add(dictionary[i]);
        }
    }

    // Returns the set of all valid words in the given Boggle board, as an Iterable.
    public Iterable<String> getAllValidWords(BoggleBoard board){
        SET<String> validWordsSet = new SET<String>();
        for(int row = 0; row < board.rows(); row++){
            for(int col = 0; col < board.cols(); col++){
                boolean[][] marked = new boolean[board.rows()][board.cols()];
                collect(board, row, col, marked, "", validWordsSet);
                //StdOut.printf("\nrow=%d col=%d",row,col);
            }
        }
        return validWordsSet;
    }
    private void collect(BoggleBoard board, int row, int col, boolean[][] marked, String prefix, SET<String> vwordset){
        // recrusive method to find all wordInBorad whether in dictionary
        // step_0 recrusive STOP 
        if(marked[row][col] == true) return;
        // step_0 recrusive SUCC - run algo( A\get the new word, B\check the new Word, C\marked_row_col, D\goto next recrusive,)
        //StdOut.printf("\nrow=%d col=%d",row,col);
        String word = prefix;
        if(board.getLetter(row,col) == 'Q'){
            word += "QU";
        }
        else{
           word += board.getLetter(row,col);
        }
        //StdOut.printf("\n%s",prefix);
        //StdOut.printf("\n%s",board.getLetter(row,col));
        //StdOut.printf("\n%s",word);
        if(word.length()>2 && dictSet.contains(word)) vwordset.add(word);
        marked[row][col] = true;
        int[] dx = {-1,0,1};
        int[] dy = {-1,0,1};
        for(int i=0;i<dx.length;i++){
            for(int j=0;j<dy.length;j++){
                if(i == 1 && j == 1) continue;
                if(row+dx[i]>-1 && row+dx[i]<board.rows() && col+dy[j]>-1 && col+dy[j]<board.cols() && (marked[row+dx[i]][col+dy[j]]==false)){
                    collect(board, row+dx[i], col+dy[j], marked, word, vwordset);
                    marked[row+dx[i]][col+dy[j]] = false;
                }
            }
        }
    }
    
    // Returns the score of the given word if it is in the dictionary, zero otherwise.
    // (You can assume the word contains only the uppercase letters A through Z.)
    public int scoreOf(String word){
        if(word == null) throw new IllegalArgumentException();
        if(dictSet.contains(word)){
            if(word.length() < 3) return 0;
            else if(word.length() < 5) return 1;
            else if(word.length() < 6) return 2;
            else if(word.length() < 7) return 3;
            else if(word.length() < 8) return 5;
            else return 11;
        }
        else return 0;
    }
    // test function (optional)
    public static void main(String[] args) {
        In in = new In(args[0]);
        String[] dictionary = in.readAllStrings();
        BoggleSolver solver = new BoggleSolver(dictionary);
        BoggleBoard board = new BoggleBoard(args[1]);
        int score = 0;
        for (String word : solver.getAllValidWords(board)) {
            //StdOut.println(word);
            score += solver.scoreOf(word);
        }
        StdOut.println("Score = " + score);
    }
}